function comment() {

    let unm = document.querySelector("#exampleFormControlInput1").value;
    let cmt = document.querySelector("#exampleFormControlTextarea1").value;

    let cb = document.querySelector("#comm");

    let par = cb.innerHTML;

    let child = `
    <div style="background-color: rgba(250, 235, 167, 0.924);border: 2px solid black;">
    <div>
        <span style="font-size:25px;">Username :</span>
        <span style="color: blue;font-size:25px;">${unm}</span>
    </div>
    <div>

        <span style="font-size:25px;">Comment :</span>
        <span style="color: blue;font-size:25px;">${cmt}</span>
    </div>
    <div>
    <span onclick=like(this,0) style="cursor: pointer;">&#128077;</span>
    <span>0</span>
    <span onclick=like(this,1) style="cursor: pointer;">&#128078;</span>
    <span>0</span>
    </div>
    </div>
    <br>
    `

    cb.innerHTML = child + par;
    unm = document.querySelector("#exampleFormControlInput1").value = "";
    cmt = document.querySelector("#exampleFormControlTextarea1").value = "";

}

function like(par, a) {
    let dta;
    if (a == 0) {
        dta = par.parentElement.children[1];
    }
    else if (a == 1) {
        dta = par.parentElement.children[3];
    }

    let inc = parseInt(dta.innerHTML);
    dta.innerHTML = inc + 1;
}
