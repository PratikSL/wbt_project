function register()
{
    var uname = document.getElementById(1).value;
    var pass = document.getElementById(2).value;

    if(uname==""||pass=="")
    {
        alert("emptyfield");
        return;
    }
    else
    {
        alert("wait a second");
        location.replace("index.html");
    }
}