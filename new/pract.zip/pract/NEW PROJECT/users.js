

async function tempp() {

    let v = document.querySelector('#ct').value;
   
    let url = `http://localhost:4000/homeshow`;

    let res = await fetch(url);
    
    let dta = await res.json();
    console.log(dta);


    let parent = document.querySelector('#out');
    let fchild = parent.innerHTML;

    let newchild = `<p style="font-size:30px;text-align:center;background:wheat;border:2px solid black"> ${dta[v].id}  ${dta[v].uname}  ${dta[v].sname}</p>`;

    parent.innerHTML = fchild + newchild;

}