function chk() {

    var x = document.getElementById("divid1").checked = 1;


    var a = document.getElementById("divid1");

    a.innerHTML = `<div style="display:none"></div>`
}